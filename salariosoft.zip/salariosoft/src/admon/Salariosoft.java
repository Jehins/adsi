//Autor Jehins León Correa. Clase principal
package admon;

import javax.swing.JOptionPane;


public class Salariosoft {

   
    public static void main(String[] args) {
        
       int idnomina, valorHextras, salarioBase,idTrabajador;
       String nombre, telefono, correo;
       float salud, pension, arl , salarioTotal;
       
       idnomina = Integer.parseInt(JOptionPane.showInputDialog("digite # nomina"));
       idTrabajador = Integer.parseInt(JOptionPane.showInputDialog("digite id trabajador"));
       salarioBase = Integer.parseInt(JOptionPane.showInputDialog("digite el salario"));
       valorHextras = Integer.parseInt(JOptionPane.showInputDialog("digite # horas extras"));       
       nombre = JOptionPane.showInputDialog("digite el nombre del trabajador");
       telefono = JOptionPane.showInputDialog("digite el telefono");
       correo = JOptionPane.showInputDialog("digite el correo");
       
       Nomina pago = new Nomina (idnomina, valorHextras, salarioBase, idTrabajador, nombre, telefono, correo);
        salud = pago.calSalud();
        pension = pago.calpension();
        arl = pago.calarl();
        salarioTotal = pago.calsalarioT(salarioBase, salud, pension, arl);
        pago.mostrarNomina();

    }
    
}
