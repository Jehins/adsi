//Autor Jehins Leon Correa clase Nomina
package admon;

import javax.swing.JOptionPane;


public class Nomina extends Trabajador{
    private int idNomina;
    private int valorHextras;
    private int salarioBase;
    private float salud;
    private float pension;
    private float arl;
    private float salarioTotal;

    public Nomina(int idNomina, int valorHextras, int salarioBase, int idTrabajador, String nombres, String telefono, String correo) {
        super(idTrabajador, nombres, telefono, correo);
        this.idNomina = idNomina;
        this.valorHextras = valorHextras;
        this.salarioBase = salarioBase;
    }

    
    public float calSalud () {
        this.salud = salarioBase * 4 / 100;
        return salud;
    }
    
    public float calpension () {
        this.pension = salarioBase * 4 / 100;
        return pension;
    }
    
    public float calarl () {
        this.arl = (float) (salarioBase * 0.52) / 100;
        return arl;
    }
    
    public float calsalarioT (int salarioBase, float salud, float pension, float arl) {
        this.salarioTotal = (salarioBase - salud - pension - arl + valorHextras);
        return salarioTotal;
    }
    
    public void mostrarNomina (){
        JOptionPane.showMessageDialog(null, "Salario Salariofoft" + "\n"
        + "id nomina:" + this.idNomina + "\n"
        + " id Trabajador:" + super.getIdTrabajador() + "\n"
        + "Nombre:" + super.getNombres() + "\n"
        + "Telefono:" + super.getTelefono()+ "\n"
        + "Correo:" + super.getCorreo()+ "\n"
        + "valor Horas Extras:" + this.valorHextras + "\n"
        + "salario Base:" + this.salarioBase + "\n"
        + "salud:" + this.salud + "\n"
        + "pension:" + this.pension + "\n"
        + "arl:" + this.arl + "\n"
        + "Salario Total:" + this.salarioTotal);
    
    }       

    
}
